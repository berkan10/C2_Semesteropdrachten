/*
* Auteur 1:Berkan Ipek
* Auteur 2:Kazim Bozca
* Auteur 3:Uzun Erdem
* Link naar github repository: https://github.com/berkan10/C2_Semesteropdrachten.git
*/







#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

						// Declaratie gebruikte types voor overzichtelijkere structs (code)
typedef uint32_t DWORD; 
typedef int32_t  LONG; 
typedef uint16_t WORD;

#pragma pack(push, 1) 
	typedef struct teInverteren 		// Deze struct gaat tijdelijk 1 byte aan waarden opslaan
	{
		unsigned char tempByte;
	}RGBSAVE;
	#pragma pack(pop)


// Struct om de infoheader op te slaan
#pragma pack(push, 1) 
typedef struct INFOHeader
{
	DWORD infoGrootte;			// Grootte van de struct (byte)
	LONG infoBreedte;			// Bitmap breedte (pixel)
	LONG infoHoogte;			// Bitmap hoogte (pixel)
	WORD kleurPlane;			
	WORD bitPerPixel;				// Variabelen van een infoheader source: https://en.wikipedia.org/wiki/BMP_file_format
	DWORD compressieType;				// Variabelen van een infoheader source: https://stackoverflow.com/questions/23725180/pixel-manipulation-on-bitmap-file-in-c
	DWORD bestandGrootte;			
	LONG xResolutie;			
	LONG yResolutie;			
	DWORD bmpKleuren;			
	DWORD bmpKleurenImp;			
}INFOHEADER;

#pragma pack(pop)
	
// Struct om de fileheader op te slaan
#pragma pack(push, 1) 
typedef struct BMPHeader				// Variabelen van een infoheader source: https://en.wikipedia.org/wiki/BMP_file_format	
{							// Variabelen van een infoheader source: https://stackoverflow.com/questions/23725180/pixel-manipulation-on-bitmap-file-in-c
	WORD bestandType; 			// File type
	DWORD bestandGrootte; 			// Grootte van de file (byte)
	WORD reserved1; 			// Reserve
	WORD reserved2;				// Reserve
	DWORD headerOffset;			// offset, geheugen adres van bitmap image data (pixel array)
}HEADER;

#pragma pack(pop)







int main()
{
	FILE *filePointerInput = NULL;
	
	filePointerInput = fopen("input.bmp", "rb"); 		// Openen van input bmp-bestand (rb = read binair)
	if(filePointerInput == NULL)
	{

			printf("Error, bestand kan niet geopend worden!\n");
			exit(EXIT_FAILURE);
			return 0;

	}
	
	FILE *filePointerOutput = NULL;
	
	filePointerOutput = fopen("output.bmp", "wb"); 		// Crëeren output bmp-bestand  (wb = wrtite binair)
	if(filePointerOutput == NULL)
	{

			printf("Error, bestand kan niet aangemaakt worden!\n");
			exit(EXIT_FAILURE);
			return 0;

	}
	
	HEADER headFile;
	INFOHEADER infoHead;
	

	// kopiëren van header informatie
	fread(&headFile, sizeof(headFile), 1, filePointerInput);
	fwrite(&headFile, sizeof(headFile), 1, filePointerOutput);
	fread(&infoHead, sizeof(infoHead), 1, filePointerInput);
	fwrite(&infoHead, sizeof(infoHead), 1, filePointerOutput);
	
	RGBSAVE saveVariable;


	unsigned char testClause = 1; 								// Test pocedure error-check op het einde van de bestand om de loop te stoppen.

	while(testClause == 1)
	{

		testClause = fread(&saveVariable.tempByte, 1, 1, filePointerInput); 		// Read value
		saveVariable.tempByte = ~saveVariable.tempByte; 				// Inverteer de waarde
		fwrite(&saveVariable.tempByte, 1, 1, filePointerOutput);			// Write value

	}
	

	
	fclose(filePointerInput);								// Einde aan transmissie van informatie
	fclose(filePointerOutput); 								 
	return 0;
}



//
//
//
//
//	Bronvermelding:
//
//	https://stackoverflow.com/questions/23725180/pixel-manipulation-on-bitmap-file-in-c
//	https://en.wikipedia.org/wiki/BMP_file_format

